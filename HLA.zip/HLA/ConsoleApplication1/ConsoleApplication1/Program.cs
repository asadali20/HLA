﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[] { 10, 20, 30, 40, 50 };
            int num = 0;
            int flag = 0;
            Console.WriteLine("enter any number");
            num = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < array.Length; i++)
            {
                if (num == array[i])
                {
                    flag = 1;
                    // Console.WriteLine("number Found");
                    //break;
                }
            }
            if (flag == 1)
            {
                Console.WriteLine("number Found");
            }
            else
            {
                Console.WriteLine("number not Found");
            }
        }
    }
}
