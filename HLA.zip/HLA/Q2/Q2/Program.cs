﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    public struct Person
    { 
        public string Name; 
        public int Age; 
        public int Weight; 
  
    } 
    class Program
    {
        static void Main(string[] args)
        {
             
            Person P1,P2; 
  
            // P1's data 
            P1.Name = "ali asad"; 
            P1.Age = 21; 
            P1.Weight = 70; 
 
            Console.WriteLine("Data Stored in P1 is " +  P1.Name + ", age is " +  P1.Age + " and weight is " +  P1.Weight);

            P2.Name = "Asad Ali";
            P2.Age = 23;
            P2.Weight = 65;

            Console.WriteLine("Data Stored in P2 is " + P2.Name + ", age is " + P2.Age + " and weight is " + P2.Weight);
        }
    }
}
